# SEG2105-Project_F18
repository link: https://github.com/GabNau/SEG2105-Project_F18.git
This is the shared repository for our Android Projectt: On-Demand Home Repair Services App

Students working on this project include:

Gabrielle Naubert 300015305
Saabiqa Chowdhury 8310026
Pratik Mistry 300029312
Rithik Sowdermett 300044941
Nikita Bliumkin 8752021

<<<<<<< HEAD
<<<<<<< HEAD
<<<<<<< HEAD
<<<<<<< HEAD
=======
>>>>>>> 9360d4704311e3371c514b9fc69ceb880b90d9cf
=======
>>>>>>> 9360d4704311e3371c514b9fc69ceb880b90d9cf
=======
>>>>>>> e6ce66c8789f67e693ef5bfb49969fc73feb8ea9

Build Status
[![Build
Status](https://circleci.com/gh/pratikmistry-99/workflows/SEG2105-Project_F18/tree/master)](https://circleci.com/gh/pratikmistry-99/workflows/SEG2105-Project_F18)



